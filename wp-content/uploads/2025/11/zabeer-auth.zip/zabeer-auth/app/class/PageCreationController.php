<?php
if (!defined('ABSPATH')) exit; // Prevent direct access

class PageCreationController
{
    public function __construct()
    {
        // Register shortcodes when class is loaded
        add_shortcode('zabeer_hello', [$this, 'zabeer_auth_shortcode_hello']);
        add_shortcode('zabeer_register', [$this, 'zabeer_auth_shortcode_register']);
    }

    // === Create Pages on Plugin Activation ===
    public static function zabeer_auth_create_page()
    {
        // Sign In page
        $signin_title   = 'Sign In';
        $signin_slug    = 'sign-in';
        $signin_content = '[zabeer_hello]';

        $signin_page = get_page_by_path($signin_slug, OBJECT, 'page');
        if (!$signin_page) {
            wp_insert_post([
                'post_title'   => $signin_title,
                'post_content' => $signin_content,
                'post_status'  => 'publish',
                'post_type'    => 'page',
                'post_name'    => $signin_slug,
            ]);
        }

        // Registration page
        $register_title   = 'Registration';
        $register_slug    = 'registration';
        $register_content = '[zabeer_register]';

        $register_page = get_page_by_path($register_slug, OBJECT, 'page');
        if (!$register_page) {
            wp_insert_post([
                'post_title'   => $register_title,
                'post_content' => $register_content,
                'post_status'  => 'publish',
                'post_type'    => 'page',
                'post_name'    => $register_slug,
            ]);
        }
    }

    // === Remove Pages on Plugin Deactivation ===
    public static function zabeer_auth_remove_page()
    {
        // Delete by slug to be resilient to title edits
        foreach (['sign-in', 'registration'] as $slug) {
            $page = get_page_by_path($slug, OBJECT, 'page');
            if ($page) {
                wp_delete_post($page->ID, true); // true = force delete, skip trash
            }
        }
    }

    // === Shortcode handlers ===
  public function zabeer_auth_shortcode_hello()
{
    ob_start();

    // If user is logged in
    if (is_user_logged_in()) {
        $logout_url = wp_logout_url(site_url('/?logged_out=true'));
        ?>
        <div style="text-align:center; padding:40px;">
            <h2>👋 Hello, <?php echo esc_html(wp_get_current_user()->display_name); ?>!</h2>
            <p>You are already logged in.</p>
            <a href="<?php echo esc_url($logout_url); ?>" 
               style="display:inline-block;padding:10px 20px;background:#c0392b;color:#fff;text-decoration:none;border-radius:6px;">
               🔒 Logout
            </a>
        </div>
        <?php
    } else {
        // If user is not logged in, render your login page
        include ZABEER_AUTH_PATH . 'template/LoginPage.php';
    }

    return ob_get_clean();
}

    public function zabeer_auth_shortcode_register()
    {
        ob_start();
        // renders templates/template-registration.php
        include ZABEER_AUTH_PATH . 'template/RegistrationPage.php';
        return ob_get_clean();
    }

    




}

new PageCreationController();
