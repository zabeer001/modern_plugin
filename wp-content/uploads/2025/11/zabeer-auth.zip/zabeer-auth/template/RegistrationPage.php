<?php
// /var/www/wordpress/modern_plugin/wp-content/plugins/zabeer-auth/template/RegistrationPage.php
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Register</title>
    <!-- Tailwind CSS CDN (only for this page) -->
    <link href="https://cdn.jsdelivr.net/npm/tailwindcss@2.2.19/dist/tailwind.min.css" rel="stylesheet">
    <style>
        /* Custom styles scoped to this page */
        .gradient-bg {
            background: linear-gradient(135deg, #6B7280, #1F2937);
            min-height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
        }
        .card {
            transition: transform 0.3s ease, box-shadow 0.3s ease;
        }
        .card:hover {
            transform: translateY(-5px);
            box-shadow: 0 10px 20px rgba(0, 0, 0, 0.2);
        }
        .btn-gradient {
            background: linear-gradient(to right, #3B82F6, #8B5CF6);
            transition: background 0.3s ease;
        }
        .btn-gradient:hover {
            background: linear-gradient(to right, #2563EB, #7C3AED);
        }
        .input-focus {
            transition: border-color 0.3s ease, box-shadow 0.3s ease;
        }
        .input-focus:focus {
            border-color: #3B82F6;
            box-shadow: 0 0 0 3px rgba(59, 130, 246, 0.3);
            outline: none;
        }
    </style>
</head>
<body class="gradient-bg">
    <div class="container mx-auto px-4">
        <div class="flex justify-center items-center">
            <div class="card bg-white rounded-2xl shadow-lg p-8 max-w-md w-full">
                <div class="text-center mb-6">
                    <h3 class="text-3xl font-bold text-gray-800">Create Account</h3>
                    <p class="text-gray-500 mt-2">Sign up for a new account</p>
                </div>
                <form id="zabeer-register-form">
                    <div class="mb-5">
                        <input 
                            type="text" 
                            id="username" 
                            class="w-full px-4 py-3 border border-gray-300 rounded-lg text-gray-700 input-focus" 
                            placeholder="Username" 
                            required
                        >
                    </div>
                    <div class="mb-5">
                        <input 
                            type="email" 
                            id="email" 
                            class="w-full px-4 py-3 border border-gray-300 rounded-lg text-gray-700 input-focus" 
                            placeholder="Email" 
                            required
                        >
                    </div>
                    <div class="mb-6">
                        <input 
                            type="password" 
                            id="password" 
                            class="w-full px-4 py-3 border border-gray-300 rounded-lg text-gray-700 input-focus" 
                            placeholder="Password" 
                            required
                        >
                    </div>
                    <button 
                        type="submit" 
                        class="btn-gradient w-full py-3 rounded-lg text-white font-semibold text-lg"
                    >
                        Register
                    </button>
                </form>
                <p class="text-center text-gray-500 mt-6">
                    Already have an account? <a href="<?php echo site_url('/dummy-page-1'); ?>" class="text-blue-500 hover:underline">Log in</a>
                </p>
            </div>
        </div>
    </div>

    <script>
        const API_URL = '<?php echo site_url(); ?>/wp-json/wp/v2/users';
        const NONCE = '<?php echo wp_create_nonce('wp_rest'); ?>';
        const LOGIN_URL = '<?php echo site_url('/dummy-page-1'); ?>';

        document.addEventListener('DOMContentLoaded', function() {
            const form = document.getElementById('zabeer-register-form');

            form.addEventListener('submit', async function(e) {
                e.preventDefault();

                const username = document.getElementById('username').value;
                const email = document.getElementById('email').value;
                const password = document.getElementById('password').value;

                try {
                    // Call WordPress REST API to register user
                    const response = await fetch(API_URL, {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            'X-WP-Nonce': NONCE
                        },
                        body: JSON.stringify({
                            username: username,
                            email: email,
                            password: password,
                            roles: ['subscriber'] // Default role for new users
                        })
                    });

                    const data = await response.json();
                    console.log(data);

                    if (response.ok && data.id) {
                        alert('Registration successful! Redirecting to login...');
                        window.location.href = LOGIN_URL;
                    } else {
                        alert('Registration failed: ' + (data.message || 'Unknown error'));
                    }
                } catch (error) {
                    console.error('Error:', error);
                    alert('An error occurred during registration. Please try again.');
                }
            });
        });
    </script>
</body>
</html>